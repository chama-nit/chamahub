-- ===========================================================================
-- ChamaHub - collaudo delle policy RLS
-- ===========================================================================
-- Da eseguire su un database in cui siano gia' state applicate _supabase_stub
-- e tutte le migrazioni:
--
--   psql -d chamatest -f supabase/tests/rls_checks.sql
--
-- Ogni blocco stampa PASS o solleva un'eccezione. Verifica che ciascun ruolo
-- veda e possa modificare esclusivamente cio' che gli compete.
-- ===========================================================================

\set ON_ERROR_STOP on
\set QUIET on

-- Su Supabase questi grant sono applicati automaticamente dalle default
-- privileges del progetto; in locale vanno riprodotti a mano.
grant select, insert, update, delete on all tables in schema public to authenticated;
grant execute on all functions in schema public to authenticated;
revoke all on public.satisfaction_submissions from anon, authenticated;
revoke all on public.satisfaction_answers from anon, authenticated;
revoke all on public.satisfaction_throttle from anon, authenticated;

-- ---------------------------------------------------------------------------
-- Dati di prova
-- ---------------------------------------------------------------------------
-- NB: mai TRUNCATE ... CASCADE su auth.users: si propagherebbe a tutte le
-- tabelle che referenziano profiles, azzerando anche modelli e questionari.
delete from auth.users;
delete from public.areas;

-- La finestra di primo avvio va chiusa esplicitamente, altrimenti il primo
-- utente inserito qui sotto verrebbe promosso a HR dal trigger e i controlli
-- non partirebbero dallo stato voluto. Il primo avvio ha una suite dedicata in
-- bootstrap_checks.sql.
update public.app_settings set value = 'false'::jsonb
where key = 'bootstrap_first_admin';

insert into auth.users (id, email, raw_user_meta_data) values
  ('11111111-1111-1111-1111-111111111111', 'hr@example.com',   '{"full_name":"Hilary Rossi"}'),
  ('22222222-2222-2222-2222-222222222222', 'mgr@example.com',  '{"full_name":"Marco Gestori"}'),
  ('33333333-3333-3333-3333-333333333333', 'emp1@example.com', '{"full_name":"Elisa Uno"}'),
  ('44444444-4444-4444-4444-444444444444', 'emp2@example.com', '{"full_name":"Enrico Due"}'),
  ('55555555-5555-5555-5555-555555555555', 'new@example.com',  '{"full_name":"Nuovo Arrivato"}'),
  ('66666666-6666-6666-6666-666666666666', 'root@example.com', '{"full_name":"Sara Sistemi"}');

insert into public.areas (id, name) values
  ('aaaaaaaa-0000-0000-0000-000000000001', 'Sviluppo'),
  ('aaaaaaaa-0000-0000-0000-000000000002', 'Amministrazione');

update public.profiles set role = 'hr', is_active = true
  where id = '11111111-1111-1111-1111-111111111111';
update public.profiles set is_active = true,
  area_id = 'aaaaaaaa-0000-0000-0000-000000000001'
  where id = '22222222-2222-2222-2222-222222222222';
-- Dalla migrazione 18 il ruolo `manager` non si assegna piu' a mano: si nomina
-- la persona responsabile di un'area e il trigger allinea il ruolo.
insert into public.area_managers (area_id, profile_id)
values ('aaaaaaaa-0000-0000-0000-000000000001',
        '22222222-2222-2222-2222-222222222222');
update public.profiles set is_active = true,
  area_id = 'aaaaaaaa-0000-0000-0000-000000000001'
  where id = '33333333-3333-3333-3333-333333333333';
update public.profiles set is_active = true,
  area_id = 'aaaaaaaa-0000-0000-0000-000000000002'
  where id = '44444444-4444-4444-4444-444444444444';
update public.profiles set role = 'sysadmin', is_active = true
  where id = '66666666-6666-6666-6666-666666666666';
-- '55555555' resta is_active = false: simula il primo accesso Microsoft di
-- una persona non ancora censita dall'HR.

-- ---------------------------------------------------------------------------
-- Helper di asserzione
-- ---------------------------------------------------------------------------
create or replace function pg_temp.assert(p_condition boolean, p_label text)
returns void language plpgsql as $$
begin
  if p_condition then
    raise notice 'PASS  %', p_label;
  else
    raise exception 'FAIL  %', p_label;
  end if;
end $$;

create or replace function pg_temp.expect_error(p_sql text, p_label text)
returns void language plpgsql as $$
begin
  begin
    execute p_sql;
  exception when others then
    raise notice 'PASS  % (bloccato: %)', p_label, left(sqlerrm, 60);
    return;
  end;
  raise exception 'FAIL  % - l''operazione avrebbe dovuto essere rifiutata', p_label;
end $$;

\set QUIET off

-- ===========================================================================
-- 1. Calendario
-- ===========================================================================
begin;
  set local role authenticated;
  set local request.jwt.claim.sub = '33333333-3333-3333-3333-333333333333';

  insert into public.calendar_entries (profile_id, entry_date, type)
  values ('33333333-3333-3333-3333-333333333333', current_date, 'smart_working');

  select pg_temp.assert(
    (select area_id from public.calendar_entries
      where profile_id = '33333333-3333-3333-3333-333333333333')
      = 'aaaaaaaa-0000-0000-0000-000000000001',
    'calendario: area_id valorizzata automaticamente dal trigger');

  select pg_temp.expect_error(
    $q$insert into public.calendar_entries (profile_id, entry_date, type)
       values ('44444444-4444-4444-4444-444444444444', current_date, 'office')$q$,
    'calendario: un dipendente non puo'' inserire giornate per un collega');
commit;

begin;
  set local role authenticated;
  set local request.jwt.claim.sub = '44444444-4444-4444-4444-444444444444';
  insert into public.calendar_entries (profile_id, entry_date, type, absence_kind)
  values ('44444444-4444-4444-4444-444444444444', current_date, 'absence', 'vacation');
commit;

begin;
  set local role authenticated;
  set local request.jwt.claim.sub = '22222222-2222-2222-2222-222222222222';
  select pg_temp.assert(
    (select count(*) from public.calendar_entries) = 1,
    'calendario: il responsabile vede solo la propria area');
commit;

begin;
  set local role authenticated;
  set local request.jwt.claim.sub = '11111111-1111-1111-1111-111111111111';
  select pg_temp.assert(
    (select count(*) from public.calendar_entries) = 2,
    'calendario: l''HR vede tutta l''azienda');
commit;

begin;
  set local role authenticated;
  set local request.jwt.claim.sub = '55555555-5555-5555-5555-555555555555';
  select pg_temp.assert(
    (select count(*) from public.calendar_entries) = 0,
    'calendario: un account non ancora attivato non vede nulla');
  select pg_temp.expect_error(
    $q$insert into public.calendar_entries (profile_id, entry_date, type)
       values ('55555555-5555-5555-5555-555555555555', current_date, 'office')$q$,
    'calendario: un account non attivato non puo'' scrivere');
commit;

-- Sostituzione giornata intera / mezze giornate
begin;
  set local role authenticated;
  set local request.jwt.claim.sub = '33333333-3333-3333-3333-333333333333';
  insert into public.calendar_entries (profile_id, entry_date, period, type)
  values ('33333333-3333-3333-3333-333333333333', current_date + 1, 'morning', 'office');
  insert into public.calendar_entries (profile_id, entry_date, period, type)
  values ('33333333-3333-3333-3333-333333333333', current_date + 1, 'afternoon', 'smart_working');
  select pg_temp.assert(
    (select count(*) from public.calendar_entries
      where entry_date = current_date + 1) = 2,
    'calendario: mattina e pomeriggio convivono');

  insert into public.calendar_entries (profile_id, entry_date, period, type)
  values ('33333333-3333-3333-3333-333333333333', current_date + 1, 'full_day', 'office');
  select pg_temp.assert(
    (select count(*) from public.calendar_entries
      where entry_date = current_date + 1) = 1,
    'calendario: la giornata intera sostituisce le mezze giornate');
commit;

-- ===========================================================================
-- 2. Escalation di privilegi
-- ===========================================================================
begin;
  set local role authenticated;
  set local request.jwt.claim.sub = '33333333-3333-3333-3333-333333333333';
  select pg_temp.expect_error(
    $q$update public.profiles set role = 'hr'
       where id = '33333333-3333-3333-3333-333333333333'$q$,
    'profili: un dipendente non puo'' promuoversi a HR');
  select pg_temp.expect_error(
    $q$update public.profiles set area_id = 'aaaaaaaa-0000-0000-0000-000000000002'
       where id = '33333333-3333-3333-3333-333333333333'$q$,
    'profili: un dipendente non puo'' cambiarsi area');

  update public.profiles set phone = '+39 000 0000000'
  where id = '33333333-3333-3333-3333-333333333333';
  select pg_temp.assert(true, 'profili: il dipendente puo'' aggiornare i propri recapiti');
commit;

begin;
  set local role authenticated;
  set local request.jwt.claim.sub = '22222222-2222-2222-2222-222222222222';
  -- La policy di UPDATE consente solo il proprio profilo: l'istruzione non
  -- solleva un errore, semplicemente non trova righe su cui agire.
  update public.profiles set role = 'hr'
  where id = '33333333-3333-3333-3333-333333333333';
  select pg_temp.assert(
    (select role from public.profiles where id = '33333333-3333-3333-3333-333333333333')
      = 'employee',
    'profili: un responsabile non puo'' cambiare il ruolo dei collaboratori');
  select pg_temp.assert(
    (select count(*) from public.profiles) = 2,
    'profili: il responsabile vede se stesso e i collaboratori della sua area');
commit;

begin;
  set local role authenticated;
  set local request.jwt.claim.sub = '11111111-1111-1111-1111-111111111111';
  insert into public.area_managers (area_id, profile_id)
  values ('aaaaaaaa-0000-0000-0000-000000000001',
          '33333333-3333-3333-3333-333333333333');
  select pg_temp.assert(
    (select role from public.profiles where id = '33333333-3333-3333-3333-333333333333')
      = 'manager',
    'profili: nominando un responsabile il ruolo si allinea da solo');
  delete from public.area_managers
  where profile_id = '33333333-3333-3333-3333-333333333333';
  select pg_temp.assert(
    (select role from public.profiles where id = '33333333-3333-3333-3333-333333333333')
      = 'employee',
    'profili: revocata l''ultima area, il ruolo torna dipendente');

  select pg_temp.expect_error(
    $q$update public.profiles set role = 'employee'
       where id = '11111111-1111-1111-1111-111111111111'$q$,
    'profili: un HR non puo'' revocare il proprio stesso ruolo');
commit;

-- ===========================================================================
-- 3. Richieste
-- ===========================================================================
begin;
  set local role authenticated;
  set local request.jwt.claim.sub = '33333333-3333-3333-3333-333333333333';
  insert into public.requests (requester_id, recipient, category, subject, body)
  values ('33333333-3333-3333-3333-333333333333', 'manager', 'vacation',
          'Ferie di agosto', 'Vorrei prendere due settimane.');
  insert into public.requests (requester_id, recipient, category, subject, body)
  values ('33333333-3333-3333-3333-333333333333', 'hr', 'administrative',
          'Certificato di servizio', 'Mi servirebbe per la banca.');
commit;

begin;
  set local role authenticated;
  set local request.jwt.claim.sub = '44444444-4444-4444-4444-444444444444';
  select pg_temp.assert(
    (select count(*) from public.requests) = 0,
    'richieste: un collega di un''altra area non vede nulla');
commit;

begin;
  set local role authenticated;
  set local request.jwt.claim.sub = '22222222-2222-2222-2222-222222222222';
  select pg_temp.assert(
    (select count(*) from public.requests) = 1,
    'richieste: il responsabile vede solo quelle indirizzate a lui');
  update public.requests set status = 'closed', resolution = 'Approvato'
  where recipient = 'manager';
  select pg_temp.assert(
    (select closed_at is not null from public.requests where recipient = 'manager'),
    'richieste: closed_at valorizzato automaticamente alla chiusura');
commit;

begin;
  set local role authenticated;
  set local request.jwt.claim.sub = '11111111-1111-1111-1111-111111111111';
  select pg_temp.assert(
    (select count(*) from public.requests) = 2,
    'richieste: l''HR vede tutte le richieste');

  -- L'HR e' il destinatario delle richieste, non un mittente: una richiesta
  -- dell'HR all'HR arriverebbe a se' stessa.
  select pg_temp.expect_error(
    $q$insert into public.requests (requester_id, recipient, category, subject, body)
       values ('11111111-1111-1111-1111-111111111111', 'hr', 'other',
               'Prova', 'Non deve passare')$q$,
    'richieste: l''HR non puo'' aprire una richiesta all''HR');

  select pg_temp.expect_error(
    $q$insert into public.requests (requester_id, recipient, category, subject, body)
       values ('11111111-1111-1111-1111-111111111111', 'manager', 'other',
               'Prova', 'Non deve passare')$q$,
    'richieste: l''HR non puo'' aprire una richiesta al responsabile');
commit;

begin;
  set local role authenticated;
  set local request.jwt.claim.sub = '33333333-3333-3333-3333-333333333333';
  -- Il divieto riguarda solo l'HR: per gli altri nulla e' cambiato.
  insert into public.requests (requester_id, recipient, category, subject, body)
  values ('33333333-3333-3333-3333-333333333333', 'hr', 'training',
          'Corso di aggiornamento', 'Vorrei partecipare al corso di ottobre.');
  select pg_temp.assert(
    (select count(*) from public.requests
      where requester_id = '33333333-3333-3333-3333-333333333333') = 3,
    'richieste: un dipendente continua a poterne aprire');
commit;

-- ===========================================================================
-- 4. Valutazioni
-- ===========================================================================
begin;
  set local role authenticated;
  set local request.jwt.claim.sub = '11111111-1111-1111-1111-111111111111';

  insert into public.evaluation_campaigns (id, name, template_id, ends_on, status)
  select 'cccccccc-0000-0000-0000-000000000001',
         'Valutazione 2026',
         id,
         current_date + 30,
         'open'
  from public.evaluation_templates where target = 'employee' limit 1;

  insert into public.evaluations (id, campaign_id, template_id, subject_id, evaluator_id, area_id, kind)
  select 'dddddddd-0000-0000-0000-000000000001',
         'cccccccc-0000-0000-0000-000000000001',
         c.template_id,
         '33333333-3333-3333-3333-333333333333',
         '22222222-2222-2222-2222-222222222222',
         'aaaaaaaa-0000-0000-0000-000000000001',
         'manager_review'
  from public.evaluation_campaigns c
  where c.id = 'cccccccc-0000-0000-0000-000000000001';
commit;

begin;
  set local role authenticated;
  set local request.jwt.claim.sub = '33333333-3333-3333-3333-333333333333';
  select pg_temp.assert(
    (select count(*) from public.evaluations) = 0,
    'valutazioni: il valutato non vede la scheda finche'' non e'' consegnata');
commit;

begin;
  set local role authenticated;
  set local request.jwt.claim.sub = '22222222-2222-2222-2222-222222222222';
  select pg_temp.assert(
    (select count(*) from public.evaluations) = 1,
    'valutazioni: il responsabile vede la scheda da compilare');

  insert into public.evaluation_answers (evaluation_id, question_id, numeric_value)
  select 'dddddddd-0000-0000-0000-000000000001', q.id, 4
  from public.evaluation_questions q
  join public.evaluations e on e.id = 'dddddddd-0000-0000-0000-000000000001'
  where q.template_id = e.template_id and q.type = 'scale';

  select pg_temp.assert(
    (select count(*) from public.evaluation_answers) = 6,
    'valutazioni: il responsabile puo'' salvare le risposte in bozza');

  select pg_temp.expect_error(
    $q$update public.evaluations set status = 'submitted'
       where id = 'dddddddd-0000-0000-0000-000000000001'$q$,
    'valutazioni: la consegna non e'' possibile direttamente dal client');
commit;

-- Consegna eseguita come farebbe la Edge Function (service_role).
begin;
  update public.evaluations
  set status = 'submitted', submitted_at = now(), overall_score = 80
  where id = 'dddddddd-0000-0000-0000-000000000001';
commit;

begin;
  set local role authenticated;
  set local request.jwt.claim.sub = '33333333-3333-3333-3333-333333333333';
  select pg_temp.assert(
    (select count(*) from public.evaluations) = 1,
    'valutazioni: dopo la consegna il valutato vede la propria scheda');
  select pg_temp.assert(
    (select count(*) from public.evaluation_answers) = 6,
    'valutazioni: il valutato vede anche le risposte della scheda consegnata');
commit;

begin;
  set local role authenticated;
  set local request.jwt.claim.sub = '22222222-2222-2222-2222-222222222222';
  -- La policy di UPDATE esclude le schede consegnate: l'istruzione non trova
  -- righe su cui agire e nulla viene modificato.
  update public.evaluations set comment = 'ripensamento'
  where id = 'dddddddd-0000-0000-0000-000000000001';
  select pg_temp.assert(
    (select comment is null from public.evaluations
      where id = 'dddddddd-0000-0000-0000-000000000001'),
    'valutazioni: una scheda consegnata non e'' piu'' modificabile');

  select pg_temp.expect_error(
    $q$insert into public.evaluation_answers (evaluation_id, question_id, text_value)
       select 'dddddddd-0000-0000-0000-000000000001', q.id, 'tardivo'
       from public.evaluation_questions q where q.type = 'text' limit 1$q$,
    'valutazioni: non si possono aggiungere risposte a una scheda consegnata');
commit;

-- ===========================================================================
-- 5. Gradimento: anonimato
-- ===========================================================================
-- Compilazioni inserite come farebbe la Edge Function (service_role).
begin;
  insert into public.satisfaction_submissions (id, survey_id, area_id)
  select ('eeeeeeee-0000-0000-0000-00000000000' || g)::uuid, s.id,
         'aaaaaaaa-0000-0000-0000-000000000001'
  from public.satisfaction_surveys s, generate_series(1, 4) g
  where s.name = 'Gradimento del lavoro';

  insert into public.satisfaction_answers (submission_id, question_id, numeric_value)
  select sub.id, q.id, 4
  from public.satisfaction_submissions sub
  join public.satisfaction_questions q on q.survey_id = sub.survey_id
  where q.type = 'scale';
commit;

begin;
  set local role authenticated;
  set local request.jwt.claim.sub = '11111111-1111-1111-1111-111111111111';
  select pg_temp.expect_error(
    'select count(*) from public.satisfaction_submissions',
    'gradimento: nemmeno l''HR puo'' leggere le compilazioni grezze');
commit;

begin;
  set local role authenticated;
  set local request.jwt.claim.sub = '33333333-3333-3333-3333-333333333333';
  select pg_temp.expect_error(
    'select count(*) from public.satisfaction_answers',
    'gradimento: un dipendente non puo'' leggere le risposte grezze');
  select pg_temp.expect_error(
    'select * from public.satisfaction_kpi_by_area()',
    'gradimento: un dipendente non puo'' accedere ai KPI');
commit;

begin;
  set local role authenticated;
  set local request.jwt.claim.sub = '11111111-1111-1111-1111-111111111111';
  select pg_temp.assert(
    (select count(*) from public.satisfaction_kpi_by_area()) = 2,
    'gradimento: l''HR ottiene i KPI di tutte le aree');
  select pg_temp.assert(
    (select avg_score from public.satisfaction_kpi_by_area()
      where area_id = 'aaaaaaaa-0000-0000-0000-000000000001') = 4.00,
    'gradimento: media calcolata correttamente sopra la soglia minima');
  select pg_temp.assert(
    (select below_threshold from public.satisfaction_kpi_by_area()
      where area_id = 'aaaaaaaa-0000-0000-0000-000000000002'),
    'gradimento: area senza risposte marcata sotto soglia');
  select pg_temp.assert(
    (select avg_score is null from public.satisfaction_kpi_by_area()
      where area_id = 'aaaaaaaa-0000-0000-0000-000000000002'),
    'gradimento: nessun dato esposto per le aree sotto soglia');
commit;

begin;
  set local role authenticated;
  set local request.jwt.claim.sub = '22222222-2222-2222-2222-222222222222';
  select pg_temp.assert(
    (select count(*) from public.satisfaction_kpi_by_area()) = 1,
    'gradimento: il responsabile vede i KPI della sola area di competenza');
commit;

-- ===========================================================================
-- 6. Riepilogo dashboard
-- ===========================================================================
begin;
  set local role authenticated;
  set local request.jwt.claim.sub = '11111111-1111-1111-1111-111111111111';
  select pg_temp.assert(
    (public.my_dashboard_summary() ->> 'role') = 'hr',
    'dashboard: il riepilogo HR viene generato');
commit;

begin;
  set local role authenticated;
  set local request.jwt.claim.sub = '55555555-5555-5555-5555-555555555555';
  select pg_temp.assert(
    (public.my_dashboard_summary() ->> 'active') = 'false',
    'dashboard: un account non attivato riceve active = false');
commit;


-- ===========================================================================
-- 7. Autovalutazione del dipendente, correggibile dal responsabile
-- ===========================================================================
begin;
  set local role authenticated;
  set local request.jwt.claim.sub = '11111111-1111-1111-1111-111111111111';

  insert into public.evaluations
    (id, campaign_id, template_id, subject_id, evaluator_id, area_id, kind)
  select 'dddddddd-0000-0000-0000-000000000002',
         'cccccccc-0000-0000-0000-000000000001',
         t.id,
         '33333333-3333-3333-3333-333333333333',
         '33333333-3333-3333-3333-333333333333',
         'aaaaaaaa-0000-0000-0000-000000000001',
         'self_assessment'
  from public.evaluation_templates t where t.target = 'self' limit 1;
commit;

begin;
  set local role authenticated;
  set local request.jwt.claim.sub = '33333333-3333-3333-3333-333333333333';
  select pg_temp.assert(
    (select count(*) from public.evaluations
      where id = 'dddddddd-0000-0000-0000-000000000002') = 1,
    'autovalutazione: il dipendente vede la propria scheda da compilare');

  insert into public.evaluation_answers (evaluation_id, question_id, numeric_value)
  select 'dddddddd-0000-0000-0000-000000000002', q.id, 3
  from public.evaluation_questions q
  join public.evaluations e on e.id = 'dddddddd-0000-0000-0000-000000000002'
  where q.template_id = e.template_id and q.type = 'scale';

  select pg_temp.assert(
    (select count(*) from public.evaluation_answers
      where evaluation_id = 'dddddddd-0000-0000-0000-000000000002') > 0,
    'autovalutazione: il dipendente puo'' compilarla');
commit;

begin;
  set local role authenticated;
  set local request.jwt.claim.sub = '22222222-2222-2222-2222-222222222222';
  select pg_temp.assert(
    (select count(*) from public.evaluations
      where id = 'dddddddd-0000-0000-0000-000000000002') = 1,
    'autovalutazione: il responsabile d''area la vede');

  update public.evaluation_answers
  set numeric_value = 5
  where evaluation_id = 'dddddddd-0000-0000-0000-000000000002'
    and numeric_value = 3;

  select pg_temp.assert(
    (select corrected_by from public.evaluations
      where id = 'dddddddd-0000-0000-0000-000000000002')
      = '22222222-2222-2222-2222-222222222222',
    'autovalutazione: la correzione del responsabile lascia traccia');
commit;

-- Un responsabile di un'ALTRA area non deve poterci mettere mano.
begin;
  set local role authenticated;
  set local request.jwt.claim.sub = '11111111-1111-1111-1111-111111111111';
  insert into public.area_managers (area_id, profile_id)
  values ('aaaaaaaa-0000-0000-0000-000000000002',
          '44444444-4444-4444-4444-444444444444');
commit;

begin;
  set local role authenticated;
  set local request.jwt.claim.sub = '44444444-4444-4444-4444-444444444444';
  select pg_temp.assert(
    (select count(*) from public.evaluations
      where id = 'dddddddd-0000-0000-0000-000000000002') = 0,
    'autovalutazione: un responsabile di altra area non la vede');

  update public.evaluation_answers
  set numeric_value = 1
  where evaluation_id = 'dddddddd-0000-0000-0000-000000000002';

  select pg_temp.assert(
    (select count(*) from public.evaluation_answers
      where evaluation_id = 'dddddddd-0000-0000-0000-000000000002'
        and numeric_value = 1) = 0,
    'autovalutazione: un responsabile di altra area non puo'' correggerla');
commit;

-- Nemmeno un collega dipendente della stessa area.
begin;
  set local role authenticated;
  set local request.jwt.claim.sub = '11111111-1111-1111-1111-111111111111';
  update public.profiles set role = 'employee', area_id = 'aaaaaaaa-0000-0000-0000-000000000001'
  where id = '44444444-4444-4444-4444-444444444444';
commit;

begin;
  set local role authenticated;
  set local request.jwt.claim.sub = '44444444-4444-4444-4444-444444444444';
  select pg_temp.assert(
    (select count(*) from public.evaluations
      where id = 'dddddddd-0000-0000-0000-000000000002') = 0,
    'autovalutazione: un collega della stessa area non la vede');
commit;

-- ===========================================================================
-- 7. Campagne: modifica e cancellazione solo in bozza
-- ===========================================================================
begin;
  set local role authenticated;
  set local request.jwt.claim.sub = '11111111-1111-1111-1111-111111111111';

  insert into public.evaluation_campaigns (id, name, template_id, ends_on, status)
  select 'cccccccc-0000-0000-0000-000000000002',
         'Bozza da modificare',
         t.id,
         current_date + 30,
         'draft'
  from public.evaluation_templates t where t.target = 'employee' limit 1;

  update public.evaluation_campaigns
  set name = 'Bozza rinominata', ends_on = current_date + 45
  where id = 'cccccccc-0000-0000-0000-000000000002';

  select pg_temp.assert(
    (select name from public.evaluation_campaigns
      where id = 'cccccccc-0000-0000-0000-000000000002') = 'Bozza rinominata',
    'campagne: una bozza si modifica');

  select pg_temp.expect_error(
    $q$update public.evaluation_campaigns set status = 'open'
       where id = 'cccccccc-0000-0000-0000-000000000002'$q$,
    'campagne: lo stato non si cambia a mano dal client');

  delete from public.evaluation_campaigns
  where id = 'cccccccc-0000-0000-0000-000000000002';

  select pg_temp.assert(
    (select count(*) from public.evaluation_campaigns
      where id = 'cccccccc-0000-0000-0000-000000000002') = 0,
    'campagne: una bozza si cancella');
commit;

-- La campagna 'cccccccc-0000-0000-0000-000000000001' e' stata aperta dai
-- controlli precedenti: da qui in poi e' intoccabile.
begin;
  set local role authenticated;
  set local request.jwt.claim.sub = '11111111-1111-1111-1111-111111111111';

  select pg_temp.expect_error(
    $q$update public.evaluation_campaigns set name = 'Cambio proibito'
       where id = 'cccccccc-0000-0000-0000-000000000001'$q$,
    'campagne: una campagna aperta non si modifica');

  select pg_temp.expect_error(
    $q$delete from public.evaluation_campaigns
       where id = 'cccccccc-0000-0000-0000-000000000001'$q$,
    'campagne: una campagna aperta non si cancella');
commit;

-- ===========================================================================
-- 8. SystemAdmin
-- ===========================================================================
begin;
  set local role authenticated;
  set local request.jwt.claim.sub = '66666666-6666-6666-6666-666666666666';

  select pg_temp.assert(
    public.is_sysadmin() and public.is_hr(),
    'sysadmin: eredita i permessi dell''HR');

  select pg_temp.assert(
    (select count(*) from public.profiles) >= 6,
    'sysadmin: vede tutta l''anagrafica');

  select pg_temp.expect_error(
    $q$update public.profiles set role = 'employee'
       where id = '66666666-6666-6666-6666-666666666666'$q$,
    'sysadmin: non puo'' togliersi il ruolo da solo');
commit;

begin;
  set local role authenticated;
  set local request.jwt.claim.sub = '11111111-1111-1111-1111-111111111111';

  select pg_temp.expect_error(
    $q$update public.profiles set role = 'sysadmin'
       where id = '33333333-3333-3333-3333-333333333333'$q$,
    'sysadmin: l''HR non puo'' nominarne uno');

  select pg_temp.expect_error(
    $q$update public.profiles set is_active = false
       where id = '66666666-6666-6666-6666-666666666666'$q$,
    'sysadmin: l''HR non puo'' disattivarlo');
commit;

-- Il registro delle impersonificazioni e' riservato al sysadmin.
begin;
  set local role authenticated;
  set local request.jwt.claim.sub = '11111111-1111-1111-1111-111111111111';
  select pg_temp.assert(
    (select count(*) from public.impersonation_log) = 0,
    'sysadmin: il registro non e'' leggibile dall''HR');
commit;

-- Richieste: nemmeno il sysadmin ne apre.
begin;
  set local role authenticated;
  set local request.jwt.claim.sub = '66666666-6666-6666-6666-666666666666';
  select pg_temp.expect_error(
    $q$insert into public.requests (requester_id, recipient, category, subject, body)
       values ('66666666-6666-6666-6666-666666666666', 'hr', 'other',
               'Prova', 'Non deve passare')$q$,
    'richieste: il sysadmin non puo'' aprirne');
commit;

-- ===========================================================================
-- 9. Punteggio prima e dopo la correzione
-- ===========================================================================
-- La scheda viene consegnata con risposte basse, poi il responsabile le alza:
-- il punteggio attuale deve salire e quello originale restare fermo.
begin;
  set local role authenticated;
  set local request.jwt.claim.sub = '11111111-1111-1111-1111-111111111111';

  insert into public.evaluations
    (id, campaign_id, template_id, subject_id, evaluator_id, area_id, kind)
  select 'dddddddd-0000-0000-0000-000000000003',
         'cccccccc-0000-0000-0000-000000000001',
         t.id,
         '44444444-4444-4444-4444-444444444444',
         '44444444-4444-4444-4444-444444444444',
         'aaaaaaaa-0000-0000-0000-000000000001',
         'self_assessment'
  from public.evaluation_templates t where t.target = 'self' limit 1;
commit;

begin;
  set local role authenticated;
  set local request.jwt.claim.sub = '44444444-4444-4444-4444-444444444444';
  insert into public.evaluation_answers (evaluation_id, question_id, numeric_value)
  select 'dddddddd-0000-0000-0000-000000000003', q.id, q.scale_min
  from public.evaluation_questions q
  join public.evaluations e on e.id = 'dddddddd-0000-0000-0000-000000000003'
  where q.template_id = e.template_id and q.type = 'scale';
commit;

-- Consegna: la fa la Edge Function con service_role, qui si riproduce lo
-- stesso contesto (nessun auth.uid()).
begin;
  reset role;
  update public.evaluations
  set status = 'submitted',
      submitted_at = now(),
      overall_score = public.evaluation_score('dddddddd-0000-0000-0000-000000000003')
  where id = 'dddddddd-0000-0000-0000-000000000003';

  select pg_temp.assert(
    (select overall_score from public.evaluations
      where id = 'dddddddd-0000-0000-0000-000000000003') = 0,
    'punteggio: risposte al minimo della scala valgono zero');
commit;

begin;
  set local role authenticated;
  set local request.jwt.claim.sub = '22222222-2222-2222-2222-222222222222';

  update public.evaluation_answers a
  set numeric_value = q.scale_max
  from public.evaluation_questions q
  where q.id = a.question_id
    and a.evaluation_id = 'dddddddd-0000-0000-0000-000000000003';

  select pg_temp.assert(
    (select original_score from public.evaluations
      where id = 'dddddddd-0000-0000-0000-000000000003') = 0,
    'punteggio: la correzione conserva quello originale');

  select pg_temp.assert(
    (select overall_score from public.evaluations
      where id = 'dddddddd-0000-0000-0000-000000000003') = 100,
    'punteggio: la correzione ricalcola quello attuale');

  select pg_temp.assert(
    (select corrected_by from public.evaluations
      where id = 'dddddddd-0000-0000-0000-000000000003')
      = '22222222-2222-2222-2222-222222222222',
    'punteggio: resta registrato chi ha corretto');
commit;

-- ===========================================================================
-- Migrazione 18: un responsabile su piu' aree
-- ===========================================================================
-- Marco (2222) guida Sviluppo. Qui gli si affida anche Amministrazione, dove
-- lavora Enrico (4444), e si verifica che veda entrambe senza che nulla trapeli
-- da una terza area.
begin;
  set local role authenticated;
  set local request.jwt.claim.sub = '11111111-1111-1111-1111-111111111111';

  insert into public.areas (id, name)
  values ('aaaaaaaa-0000-0000-0000-000000000003', 'Logistica');

  insert into public.profiles (id, email, full_name, role, area_id, is_active)
  select '77777777-7777-7777-7777-777777777777', 'log@example.com', 'Lucia Logistica',
         'employee', 'aaaaaaaa-0000-0000-0000-000000000003', true
  where false;
commit;

-- Il profilo nasce dal trigger su auth.users, non da un insert diretto.
insert into auth.users (id, email, raw_user_meta_data)
values ('77777777-7777-7777-7777-777777777777', 'log@example.com',
        '{"full_name":"Lucia Logistica"}');

begin;
  set local role authenticated;
  set local request.jwt.claim.sub = '11111111-1111-1111-1111-111111111111';
  update public.profiles set is_active = true,
    area_id = 'aaaaaaaa-0000-0000-0000-000000000003'
  where id = '77777777-7777-7777-7777-777777777777';

  -- La seconda area a Marco.
  insert into public.area_managers (area_id, profile_id)
  values ('aaaaaaaa-0000-0000-0000-000000000002',
          '22222222-2222-2222-2222-222222222222');
commit;

begin;
  set local role authenticated;
  set local request.jwt.claim.sub = '22222222-2222-2222-2222-222222222222';

  select pg_temp.assert(
    (select count(*) from public.current_managed_areas()) = 2,
    'multi-area: il responsabile risulta a capo di due aree');

  select pg_temp.assert(
    public.manages_area('aaaaaaaa-0000-0000-0000-000000000001')
    and public.manages_area('aaaaaaaa-0000-0000-0000-000000000002'),
    'multi-area: manages_area vale per entrambe');

  select pg_temp.assert(
    not public.manages_area('aaaaaaaa-0000-0000-0000-000000000003'),
    'multi-area: la terza area resta fuori');

  select pg_temp.assert(
    public.manages_profile('44444444-4444-4444-4444-444444444444'),
    'multi-area: vede come propria una persona della seconda area');

  select pg_temp.assert(
    not public.manages_profile('77777777-7777-7777-7777-777777777777'),
    'multi-area: non vede come propria una persona della terza area');

  -- Calendario: le giornate di entrambe le aree, nessuna della terza.
  select pg_temp.assert(
    (select count(*) from public.calendar_entries
      where area_id = 'aaaaaaaa-0000-0000-0000-000000000002') > 0,
    'multi-area: il calendario della seconda area e'' visibile');

  select pg_temp.assert(
    (select count(*) from public.profiles
      where area_id = 'aaaaaaaa-0000-0000-0000-000000000003') = 0,
    'multi-area: le persone della terza area restano invisibili');
commit;

-- Il riepilogo di dashboard conta la squadra di tutte le aree guidate.
begin;
  set local role authenticated;
  set local request.jwt.claim.sub = '22222222-2222-2222-2222-222222222222';
  select pg_temp.assert(
    (public.my_dashboard_summary() ->> 'team_size')::int >= 2,
    'multi-area: la squadra del riepilogo copre entrambe le aree');

  select pg_temp.assert(
    jsonb_array_length(public.my_dashboard_summary() -> 'managed_area_ids') = 2,
    'multi-area: il riepilogo elenca le due aree guidate');
commit;

-- ---------------------------------------------------------------------------
-- Due responsabili sulla stessa area: vince la prima consegna
-- ---------------------------------------------------------------------------
-- Enrico (4444) guida gia' Amministrazione. Ora quell'area ha due responsabili,
-- lui e Marco. Una scheda intestata a Enrico deve essere leggibile e
-- modificabile anche da Marco - e chiusa a entrambi dopo la consegna.
begin;
  set local role authenticated;
  set local request.jwt.claim.sub = '11111111-1111-1111-1111-111111111111';
  insert into public.evaluations
    (id, campaign_id, template_id, subject_id, evaluator_id, area_id, kind, status)
  select 'dddddddd-0000-0000-0000-000000000009',
         e.campaign_id, e.template_id,
         '77777777-7777-7777-7777-777777777777',
         '44444444-4444-4444-4444-444444444444',
         'aaaaaaaa-0000-0000-0000-000000000002',
         'manager_review', 'draft'
  from public.evaluations e
  where e.kind = 'manager_review' limit 1;
commit;

begin;
  set local role authenticated;
  set local request.jwt.claim.sub = '22222222-2222-2222-2222-222222222222';

  select pg_temp.assert(
    (select count(*) from public.evaluations
      where id = 'dddddddd-0000-0000-0000-000000000009') = 1,
    'co-responsabili: la scheda di un collega della stessa area e'' visibile');

  select pg_temp.assert(
    public.can_edit_evaluation('dddddddd-0000-0000-0000-000000000009'),
    'co-responsabili: la scheda e'' modificabile anche se intestata ad altri');
commit;

-- Consegnata: nessuno dei due puo' piu' toccarla.
begin;
  set local role postgres;
  update public.evaluations
  set status = 'submitted', submitted_at = now(),
      submitted_by = '22222222-2222-2222-2222-222222222222'
  where id = 'dddddddd-0000-0000-0000-000000000009';
commit;

begin;
  set local role authenticated;
  set local request.jwt.claim.sub = '22222222-2222-2222-2222-222222222222';
  select pg_temp.assert(
    not public.can_edit_evaluation('dddddddd-0000-0000-0000-000000000009'),
    'co-responsabili: dopo la consegna la scheda e'' chiusa a chiunque');

  select pg_temp.assert(
    (select submitted_by from public.evaluations
      where id = 'dddddddd-0000-0000-0000-000000000009')
      = '22222222-2222-2222-2222-222222222222',
    'co-responsabili: resta scritto chi ha consegnato');
commit;

-- ---------------------------------------------------------------------------
-- Revoca di una sola area
-- ---------------------------------------------------------------------------
begin;
  set local role authenticated;
  set local request.jwt.claim.sub = '11111111-1111-1111-1111-111111111111';
  delete from public.area_managers
  where profile_id = '22222222-2222-2222-2222-222222222222'
    and area_id = 'aaaaaaaa-0000-0000-0000-000000000002';
commit;

begin;
  set local role authenticated;
  set local request.jwt.claim.sub = '22222222-2222-2222-2222-222222222222';
  select pg_temp.assert(
    (select count(*) from public.current_managed_areas()) = 1,
    'revoca: resta l''altra area');

  select pg_temp.assert(
    (select role from public.profiles
      where id = '22222222-2222-2222-2222-222222222222') = 'manager',
    'revoca: con un''area residua il ruolo resta responsabile');

  select pg_temp.assert(
    not public.manages_area('aaaaaaaa-0000-0000-0000-000000000002'),
    'revoca: l''area revocata non e'' piu'' accessibile');
commit;

-- ===========================================================================
-- Migrazione 19: vedere il nome di chi ti scrive
-- ===========================================================================
begin;
  set local role authenticated;
  set local request.jwt.claim.sub = '33333333-3333-3333-3333-333333333333';

  -- Elisa (3333) appartiene a Sviluppo. Marco (2222) guida Sviluppo: deve
  -- vederlo anche se non e' un collega di area.
  select pg_temp.assert(
    (select count(*) from public.profiles
      where id = '22222222-2222-2222-2222-222222222222') = 1,
    'visibilita'': un dipendente vede chi guida la sua area');

  -- L'HR non appartiene a nessuna area: prima era invisibile a tutti.
  select pg_temp.assert(
    (select count(*) from public.profiles
      where id = '11111111-1111-1111-1111-111111111111') = 1,
    'visibilita'': un dipendente vede l''HP a cui ha scritto');
commit;

-- ===========================================================================
-- Migrazione 20: inoltro a un'altra area
-- ===========================================================================
-- La richiesta di Elisa e' nata in Sviluppo. Marco la inoltra ad
-- Amministrazione, dove Enrico (4444) e' responsabile.
begin;
  set local role authenticated;
  set local request.jwt.claim.sub = '33333333-3333-3333-3333-333333333333';
  insert into public.requests (id, requester_id, recipient, category, subject, body)
  values ('bbbb0000-0000-0000-0000-00000000000f',
          '33333333-3333-3333-3333-333333333333',
          'manager', 'equipment', 'Computer nuovo',
          'Il portatile non regge piu'' le compilazioni.');
commit;

begin;
  set local role authenticated;
  set local request.jwt.claim.sub = '22222222-2222-2222-2222-222222222222';

  select pg_temp.assert(
    (select count(*) from public.request_areas
      where request_id = 'bbbb0000-0000-0000-0000-00000000000f' and is_origin) = 1,
    'inoltro: l''area di origine viene registrata da sola');

  select public.forward_request(
    'bbbb0000-0000-0000-0000-00000000000f',
    'aaaaaaaa-0000-0000-0000-000000000002',
    'Serve il vostro benestare: sono circa 2000 euro.');

  select pg_temp.assert(
    (select count(*) from public.request_areas
      where request_id = 'bbbb0000-0000-0000-0000-00000000000f') = 2,
    'inoltro: l''area chiamata viene aggiunta');
commit;

-- Enrico guida Amministrazione: ora la richiesta e' anche sua.
begin;
  set local role authenticated;
  set local request.jwt.claim.sub = '44444444-4444-4444-4444-444444444444';

  select pg_temp.assert(
    (select count(*) from public.requests
      where id = 'bbbb0000-0000-0000-0000-00000000000f') = 1,
    'inoltro: il responsabile dell''area chiamata vede la richiesta');

  select pg_temp.assert(
    public.can_read_internal_notes('bbbb0000-0000-0000-0000-00000000000f'),
    'inoltro: il responsabile chiamato legge il canale riservato');

  select pg_temp.assert(
    (select count(*) from public.request_messages
      where request_id = 'bbbb0000-0000-0000-0000-00000000000f'
        and audience = 'managers') = 1,
    'inoltro: la nota riservata e'' visibile ai responsabili');

  -- Puo' a sua volta inoltrare: la catena e' ammessa.
  select public.forward_request(
    'bbbb0000-0000-0000-0000-00000000000f',
    'aaaaaaaa-0000-0000-0000-000000000003',
    null);
  select pg_temp.assert(
    (select count(*) from public.request_areas
      where request_id = 'bbbb0000-0000-0000-0000-00000000000f') = 3,
    'inoltro: l''area chiamata puo'' chiamarne un''altra');
commit;

-- Il richiedente vede l'esito ma NON il dibattito.
begin;
  set local role authenticated;
  set local request.jwt.claim.sub = '33333333-3333-3333-3333-333333333333';

  select pg_temp.assert(
    not public.can_read_internal_notes('bbbb0000-0000-0000-0000-00000000000f'),
    'inoltro: il richiedente non legge il canale riservato');

  select pg_temp.assert(
    (select count(*) from public.request_messages
      where request_id = 'bbbb0000-0000-0000-0000-00000000000f'
        and audience = 'managers') = 0,
    'inoltro: la nota fra responsabili resta invisibile al richiedente');

  select pg_temp.assert(
    (select count(*) from public.request_messages
      where request_id = 'bbbb0000-0000-0000-0000-00000000000f'
        and is_system) = 2,
    'inoltro: il richiedente vede i due passaggi di area');

  -- E non puo' scrivere nel canale riservato.
  select pg_temp.expect_error(
    $q$insert into public.request_messages (request_id, author_id, body, audience)
       values ('bbbb0000-0000-0000-0000-00000000000f',
               '33333333-3333-3333-3333-333333333333', 'di nascosto', 'managers')$q$,
    'inoltro: il richiedente non puo'' scrivere note riservate');
commit;

-- Chi non c'entra non vede niente.
begin;
  set local role authenticated;
  set local request.jwt.claim.sub = '77777777-7777-7777-7777-777777777777';
  select pg_temp.assert(
    (select count(*) from public.requests
      where id = 'bbbb0000-0000-0000-0000-00000000000f') = 0,
    'inoltro: un estraneo non vede la richiesta');
commit;

-- ===========================================================================
-- Migrazione 21: notifiche
-- ===========================================================================
begin;
  set local role authenticated;
  set local request.jwt.claim.sub = '22222222-2222-2222-2222-222222222222';
  select pg_temp.assert(
    (select count(*) from public.notifications
      where kind = 'request_opened') > 0,
    'notifiche: l''apertura di una richiesta avvisa il responsabile');

  select pg_temp.assert(
    (select count(*) from public.notifications
      where profile_id <> '22222222-2222-2222-2222-222222222222') = 0,
    'notifiche: si vedono soltanto le proprie');
commit;

begin;
  set local role authenticated;
  set local request.jwt.claim.sub = '33333333-3333-3333-3333-333333333333';

  -- Elisa ha aperto la richiesta: non deve essersi notificata da sola.
  select pg_temp.assert(
    (select count(*) from public.notifications
      where kind = 'request_opened') = 0,
    'notifiche: chi compie l''azione non riceve la propria notifica');

  select pg_temp.assert(
    (select count(*) from public.notifications
      where kind = 'request_forwarded') > 0,
    'notifiche: il richiedente viene avvisato dell''inoltro');

  select pg_temp.assert(
    (select public.mark_notifications_read()) > 0,
    'notifiche: si possono segnare come lette');

  select pg_temp.assert(
    (select count(*) from public.notifications where read_at is null) = 0,
    'notifiche: dopo la lettura non restano non lette');
commit;

-- Un profilo disattivato non riceve notifiche.
begin;
  set local role authenticated;
  set local request.jwt.claim.sub = '11111111-1111-1111-1111-111111111111';
  update public.profiles set is_active = false
  where id = '44444444-4444-4444-4444-444444444444';
commit;

-- Si azzerano le sue notifiche, si genera un evento, e si verifica che non ne
-- sia arrivata nessuna: piu' netto che confrontare due conteggi.
begin;
  set local role postgres;
  delete from public.notifications
  where profile_id = '44444444-4444-4444-4444-444444444444';
commit;

begin;
  set local role authenticated;
  set local request.jwt.claim.sub = '33333333-3333-3333-3333-333333333333';
  insert into public.request_messages (request_id, author_id, body)
  values ('bbbb0000-0000-0000-0000-00000000000f',
          '33333333-3333-3333-3333-333333333333', 'Ci sono novita''?');
commit;

begin;
  set local role postgres;
  select pg_temp.assert(
    (select count(*) from public.notifications
      where profile_id = '44444444-4444-4444-4444-444444444444') = 0,
    'notifiche: un profilo disattivato non ne riceve piu''');

  update public.profiles set is_active = true
  where id = '44444444-4444-4444-4444-444444444444';
commit;

-- ===========================================================================
-- Migrazione 22: modalita' manutenzione
-- ===========================================================================
begin;
  set local role authenticated;
  set local request.jwt.claim.sub = '33333333-3333-3333-3333-333333333333';
  select pg_temp.expect_error(
    $q$select public.set_maintenance(true, 'prova')$q$,
    'manutenzione: un dipendente non puo'' accenderla');
commit;

begin;
  set local role authenticated;
  set local request.jwt.claim.sub = '11111111-1111-1111-1111-111111111111';
  select pg_temp.expect_error(
    $q$select public.set_maintenance(true, 'prova')$q$,
    'manutenzione: nemmeno l''HR puo'' accenderla');
commit;

begin;
  set local role authenticated;
  set local request.jwt.claim.sub = '66666666-6666-6666-6666-666666666666';
  select public.set_maintenance(true, 'Aggiornamento in corso.');
  select pg_temp.assert(
    public.maintenance_active(),
    'manutenzione: il SystemAdmin la accende');
  select pg_temp.assert(
    public.maintenance_state() ->> 'message' = 'Aggiornamento in corso.',
    'manutenzione: il messaggio viene conservato');
  select pg_temp.assert(
    public.is_active_user(),
    'manutenzione: il SystemAdmin continua a operare');
commit;

begin;
  set local role authenticated;
  set local request.jwt.claim.sub = '33333333-3333-3333-3333-333333333333';
  select pg_temp.assert(
    not public.is_active_user(),
    'manutenzione: un dipendente attivo risulta bloccato');
  select pg_temp.assert(
    (select count(*) from public.calendar_entries) = 0,
    'manutenzione: le policy smettono di restituire dati');

  -- Anche i propri dati: e' il caso che la sola condizione dentro
  -- is_active_user() non copriva, perche' quelle policy guardano solo l'id.
  select pg_temp.expect_error(
    $q$insert into public.calendar_entries (profile_id, entry_date, type)
       values ('33333333-3333-3333-3333-333333333333',
               current_date + 60, 'office')$q$,
    'manutenzione: non si scrive nemmeno sul proprio calendario');
commit;

begin;
  set local role authenticated;
  set local request.jwt.claim.sub = '11111111-1111-1111-1111-111111111111';
  select pg_temp.assert(
    not public.is_active_user(),
    'manutenzione: nemmeno l''HR opera');
commit;

begin;
  set local role authenticated;
  set local request.jwt.claim.sub = '66666666-6666-6666-6666-666666666666';
  select public.set_maintenance(false, null);
  select pg_temp.assert(
    not public.maintenance_active(),
    'manutenzione: il SystemAdmin la spegne');
commit;

begin;
  set local role authenticated;
  set local request.jwt.claim.sub = '33333333-3333-3333-3333-333333333333';
  select pg_temp.assert(
    public.is_active_user(),
    'manutenzione: spenta, tutto torna come prima');
commit;

-- ===========================================================================
-- Migrazione 23: la manutenzione fa uscire davvero
-- ===========================================================================
-- Si simulano quattro sessioni aperte: HR, responsabile, dipendente e
-- SystemAdmin. Accendendo la manutenzione devono restare solo quelle del
-- SystemAdmin.
begin;
  set local role postgres;
  delete from auth.refresh_tokens;
  delete from auth.sessions;

  insert into auth.sessions (id, user_id) values
    ('ffff0000-0000-0000-0000-000000000001', '11111111-1111-1111-1111-111111111111'),
    ('ffff0000-0000-0000-0000-000000000002', '22222222-2222-2222-2222-222222222222'),
    ('ffff0000-0000-0000-0000-000000000003', '33333333-3333-3333-3333-333333333333'),
    ('ffff0000-0000-0000-0000-000000000004', '66666666-6666-6666-6666-666666666666');

  insert into auth.refresh_tokens (session_id, token) values
    ('ffff0000-0000-0000-0000-000000000003', 'token-del-dipendente'),
    ('ffff0000-0000-0000-0000-000000000004', 'token-del-sysadmin');

  select pg_temp.assert(
    (select count(*) from auth.sessions) = 4,
    'uscita: si parte da quattro sessioni aperte');
commit;

begin;
  set local role authenticated;
  set local request.jwt.claim.sub = '66666666-6666-6666-6666-666666666666';
  select public.set_maintenance(true, 'Aggiornamento serale.');
commit;

begin;
  set local role postgres;
  select pg_temp.assert(
    (select count(*) from auth.sessions) = 1,
    'uscita: restano solo le sessioni del SystemAdmin');

  select pg_temp.assert(
    (select user_id from auth.sessions)
      = '66666666-6666-6666-6666-666666666666',
    'uscita: la sessione superstite e'' quella giusta');

  select pg_temp.assert(
    (select count(*) from auth.refresh_tokens) = 1,
    'uscita: il refresh token del dipendente e'' stato revocato');

  select pg_temp.assert(
    (select token from auth.refresh_tokens) = 'token-del-sysadmin',
    'uscita: quello del SystemAdmin e'' rimasto');
commit;

-- Chi prova ad autenticarsi mentre la manutenzione e' attiva non ottiene una
-- sessione utilizzabile: il trigger la scarta appena nasce.
begin;
  set local role postgres;
  insert into auth.sessions (id, user_id)
  values ('ffff0000-0000-0000-0000-000000000005',
          '33333333-3333-3333-3333-333333333333');

  select pg_temp.assert(
    (select count(*) from auth.sessions
      where user_id = '33333333-3333-3333-3333-333333333333') = 0,
    'uscita: un accesso durante la manutenzione non lascia una sessione');

  -- Il SystemAdmin invece deve poter rientrare.
  insert into auth.sessions (id, user_id)
  values ('ffff0000-0000-0000-0000-000000000006',
          '66666666-6666-6666-6666-666666666666');

  select pg_temp.assert(
    (select count(*) from auth.sessions
      where user_id = '66666666-6666-6666-6666-666666666666') = 2,
    'uscita: il SystemAdmin puo'' aprire una nuova sessione');
commit;

-- Spenta la manutenzione, si torna a entrare normalmente.
begin;
  set local role authenticated;
  set local request.jwt.claim.sub = '66666666-6666-6666-6666-666666666666';
  select public.set_maintenance(false, null);
commit;

begin;
  set local role postgres;
  insert into auth.sessions (id, user_id)
  values ('ffff0000-0000-0000-0000-000000000007',
          '33333333-3333-3333-3333-333333333333');

  select pg_temp.assert(
    (select count(*) from auth.sessions
      where user_id = '33333333-3333-3333-3333-333333333333') = 1,
    'uscita: a manutenzione spenta le sessioni tornano a nascere');
commit;

-- Spegnere la manutenzione NON chiude sessioni: sarebbe un effetto
-- collaterale inatteso per chi e' appena rientrato.
begin;
  set local role authenticated;
  set local request.jwt.claim.sub = '66666666-6666-6666-6666-666666666666';
  select public.set_maintenance(false, null);
commit;

begin;
  set local role postgres;
  select pg_temp.assert(
    (select count(*) from auth.sessions
      where user_id = '33333333-3333-3333-3333-333333333333') = 1,
    'uscita: spegnerla non tocca le sessioni gia'' aperte');
commit;

\echo ''
\echo '================================================='
\echo ' Tutti i controlli RLS sono stati superati.'
\echo '================================================='
