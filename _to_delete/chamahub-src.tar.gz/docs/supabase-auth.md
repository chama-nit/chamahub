# Configurare Supabase Auth (e farlo parlare con Microsoft Entra)

Questa guida sta dalla parte di **Supabase**: cosa si imposta nel suo pannello,
cosa deve corrispondere in ChamaHub, e in che modo Supabase si presenta a
Microsoft Entra per farsi riconoscere.

La parte da fare su Azure — registrare l'app, creare il segreto — sta in
[`microsoft-entra-id.md`](microsoft-entra-id.md). Le due guide si incastrano:
qui trovi cosa fare **dopo** aver ottenuto i tre valori da Azure.

---

## 1. Chi autentica chi

Nel giro ci sono tre attori, e ognuno si fida del successivo per un motivo
diverso. Tenerli distinti evita la maggior parte degli errori.

```
   ChamaHub (browser)            Supabase Auth              Microsoft Entra
        |                             |                            |
   1.   |—— "voglio entrare" ———————→ |                            |
   2.   |  ←— redirect verso Microsoft |                            |
   3.   |———————————————— la persona si autentica ————————————————→ |
   4.   |                             | ←—— codice + identita' ———— |
   5.   |                             |—— client_id + secret ————→  |
   6.   |                             | ←—— token dell'utente —————  |
   7.   | ←—— sessione Supabase (JWT) |                            |
```

* **Microsoft si fida di Supabase** perche' Supabase si presenta con
  `client_id` + `client_secret` (passo 5) e perche' l'indirizzo di ritorno
  coincide con quello registrato su Azure. E' questo il senso di "autenticare
  Supabase da Entra": non c'e' un utente di servizio, c'e' un'applicazione
  registrata con un segreto.
* **ChamaHub si fida di Supabase** perche' il token di sessione (passo 7) e'
  firmato con la chiave del progetto: e' lo stesso meccanismo dell'accesso con
  email e password, il provider cambia solo il passo 3.
* **ChamaHub non parla mai con Microsoft.** Per questo l'indirizzo di ritorno
  registrato su Azure e' quello di Supabase, non il vostro dominio.

Cosa serve, in tutto:

| Valore | Da dove viene | Dove si mette |
|---|---|---|
| Application (client) ID | Azure, registrazione app | Supabase → provider Azure |
| Client secret (il *Valore*) | Azure, Certificati e segreti | Supabase → provider Azure |
| Directory (tenant) ID | Azure, panoramica | Supabase → *Azure Tenant URL* |
| Callback di Supabase | Supabase (vedi sotto) | Azure → URI di reindirizzamento |
| Project URL + anon key | Supabase → Settings → API | ChamaHub → `.env.local` |

---

## 2. Dove trovare i valori di Supabase

**Settings → API**

* **Project URL**: `https://<REFERENCE_ID>.supabase.co` → va in
  `NEXT_PUBLIC_SUPABASE_URL`.
* **anon / publishable key** → va in `NEXT_PUBLIC_SUPABASE_ANON_KEY`. E' una
  chiave pubblica per costruzione: la sicurezza vera sta nelle policy RLS.
* **service_role key**: non serve a ChamaHub e non deve mai comparire nel
  frontend. La usano solo le Edge Function, dove Supabase la inietta da sola.

**Settings → General**

* **Reference ID**: la stringa che compare in tutti gli indirizzi del progetto.
  Serve a comporre l'URL di callback:

  ```
  https://<REFERENCE_ID>.supabase.co/auth/v1/callback
  ```

  Questo e' l'indirizzo da registrare su Azure. Nella pagina del provider
  Azure, Supabase lo mostra gia' pronto da copiare.

---

## 3. Authentication → Sign In / Providers

### 3.1 Email

Resta acceso: e' l'accesso con email e password, quello che usa l'HR per creare
le persone e chiunque non abbia un account Microsoft.

| Impostazione | Consiglio | Perche' |
|---|---|---|
| **Allow new users to sign up** | **spento**, dopo aver creato il primo HR | Con la registrazione aperta chiunque conosca l'indirizzo del progetto puo' crearsi un account. Resterebbe comunque inattivo e senza dati, ma e' rumore inutile nell'anagrafica. |
| **Confirm email** | acceso se hai un SMTP funzionante, altrimenti spento | Con le conferme attive e la posta rotta, gli account creati dall'HR restano in attesa di una email che non arrivera' mai. |
| **Secure email change** | acceso | Chiede conferma su entrambi gli indirizzi quando qualcuno cambia email. |
| **Minimum password length** | 8 o piu' | ChamaHub rifiuta comunque sotto gli 8 caratteri lato interfaccia. |

### 3.2 Azure (Microsoft Entra ID)

Stessa pagina, piu' in basso nell'elenco dei provider. Attiva l'interruttore e
compila tre campi:

| Campo | Valore |
|---|---|
| **Client ID** | l'Application (client) ID della registrazione su Azure |
| **Secret** | il **Valore** del segreto client (non l'ID del segreto) |
| **Azure Tenant URL** | `https://login.microsoftonline.com/<TENANT_ID>` |

Tre avvertenze che valgono la maggior parte dei tentativi falliti:

1. **Niente `/v2.0` in fondo al Tenant URL.** Supabase completa da solo il
   percorso di scoperta OIDC; se lo aggiungi tu, diventa doppio.
2. **Il segreto scade.** Su Azure ha una data di scadenza (12 o 24 mesi, o
   quanto ha scelto chi l'ha creato). Il giorno che scade, l'accesso Microsoft
   smette di funzionare da un momento all'altro, con `AADSTS7000215` o
   `invalid_client`. Segnati la data e rigeneralo prima.
3. **Il callback mostrato in questa pagina va incollato su Azure.** Se i due
   non coincidono al carattere, Microsoft risponde `AADSTS50011`.

Sopra i campi, Supabase mostra la **Callback URL (for OAuth)**: e' esattamente
l'indirizzo del punto 2.

---

## 4. Authentication → URL Configuration

Qui si dice a Supabase dove puo' rimandare le persone **dopo** l'accesso. Se
manca, l'accesso riesce ma il ritorno viene rifiutato con *redirect_to is not
allowed*.

* **Site URL**: l'indirizzo principale dell'applicazione.
  `http://localhost:3000` in sviluppo, il dominio reale in produzione.
* **Redirect URLs**: uno per ogni ambiente da cui si accede, comprensivo del
  percorso di ritorno di ChamaHub:

  ```
  http://localhost:3000/auth/callback
  https://chamahub.tuodominio.it/auth/callback
  ```

  Serve anche il recupero password, che torna sullo stesso indirizzo con
  `?reimposta=1`: le regole ammettono i parametri, quindi la riga sopra basta.

> Non e' lo stesso campo del callback registrato su Azure. Quello riguarda il
> tratto Microsoft → Supabase; questo il tratto Supabase → ChamaHub.

---

## 5. Sessioni e token

**Authentication → Sessions** (e, in locale, `supabase/config.toml`):

| Impostazione | Valore nel progetto | Nota |
|---|---|---|
| Access token (JWT) expiry | 3600 secondi | Il token di accesso dura un'ora; la libreria lo rinnova da sola. |
| Refresh token rotation | attiva | Ogni rinnovo emette un nuovo refresh token e invalida il precedente. |
| Reuse interval | 10 secondi | Tolleranza per le richieste in parallelo, altrimenti due rinnovi contemporanei si annullerebbero a vicenda. |

Un dettaglio che ha gia' causato un errore in questo progetto: se la pagina
resta aperta a lungo il token scade, e finche' nessuno interroga il database la
libreria non se ne accorge. Per questo ChamaHub, prima di chiamare una Edge
Function, chiede sempre la sessione aggiornata: senza, si prendeva un 401 che
sembrava un problema di permessi.

---

## 6. Email

**Authentication → Emails**: il servizio integrato manda 2 messaggi all'ora e
solo ai membri del progetto — va bene per provare, non per lavorare. La
configurazione di un SMTP vero, con l'account Microsoft 365, sta in
[`email-microsoft-smtp.md`](email-microsoft-smtp.md).

Ricorda comunque che in ChamaHub quasi nulla dipende dalla posta: gli account
si creano senza, e i link di reimpostazione si generano dalla pagina Dipendenti.

---

## 7. Cosa deve corrispondere in ChamaHub

`.env.local` (e le variabili d'ambiente di produzione):

```
NEXT_PUBLIC_SUPABASE_URL=https://<REFERENCE_ID>.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOi...
# NEXT_PUBLIC_MICROSOFT_LOGIN=off   <- solo per nascondere il pulsante
```

Le variabili `NEXT_PUBLIC_*` finiscono nel bundle **in fase di compilazione**:
in produzione non basta cambiarle, serve una nuova `npm run build`.

`supabase/config.toml` serve solo a chi lavora in locale con la CLI: la sezione
`[auth.external.azure]` legge le credenziali dalle variabili d'ambiente
`AZURE_CLIENT_ID`, `AZURE_SECRET`, `AZURE_TENANT_URL`, cosi' non finiscono in
chiaro in un file versionato. Sul progetto in cloud contano solo le
impostazioni del pannello.

---

## 8. Prova finale

1. Apri la pagina di accesso di ChamaHub e premi **Accedi con account
   Microsoft**.
2. Autenticati con un utente del tenant **che l'HR ha gia' registrato e
   attivato**.
3. Devi atterrare sulla dashboard.

Se invece compare «Accesso riconosciuto, ma non ancora abilitato», la
configurazione funziona: manca solo il profilo attivo in ChamaHub. E' la
verifica che l'applicazione fa apposta — l'accesso Microsoft dice chi sei, non
che puoi entrare.

Per controllare cosa e' successo davvero: **Authentication → Users** (l'utente
compare, con provider `azure`) e **Logs → Auth Logs** per l'errore esatto in
caso di rifiuto.

---

## 9. Se qualcosa non torna

| Sintomo | Dove guardare |
|---|---|
| `AADSTS50011` — redirect mismatch | l'URI su Azure deve essere il callback di Supabase, carattere per carattere |
| `AADSTS7000215` / `invalid_client` | segreto copiato male (serve il *Valore*) o scaduto |
| `AADSTS900023` — tenant non valido | Tenant URL scritto male; niente `/v2.0` |
| `AADSTS65001` — consenso mancante | su Azure: **Concedi consenso amministratore** |
| *redirect_to is not allowed* | manca la voce in **URL Configuration → Redirect URLs** |
| Torni al login senza errori e senza sessione | **Site URL** diverso dal dominio da cui accedi |
| «L'accesso con Microsoft non e' ancora configurato» | provider Azure spento nel pannello Supabase |
| L'utente entra ma non vede nulla | profilo non attivo: e' RLS che fa il suo lavoro, attivalo dalla pagina Dipendenti |
