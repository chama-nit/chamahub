# Inviare le email con l'account Microsoft 365

Guida per far spedire a ChamaHub le email dalla casella aziendale Microsoft 365.

> **La strada consigliata e' Microsoft Graph, non SMTP.** Microsoft sta
> chiudendo l'autenticazione di base su SMTP AUTH: **da fine dicembre 2026 e'
> disattivata di default** nei tenant esistenti, dai nuovi tenant di gennaio
> 2027 non e' piu' attivabile, e la rimozione definitiva verra' annunciata nella
> seconda meta' del 2027. L'unico SMTP che sopravvivera' e' quello autenticato
> via OAuth (SASL XOAUTH2) - che il riquadro SMTP di Supabase, dove si scrivono
> host, utente e password, non sa parlare. Graph fa la stessa cosa con una
> chiamata HTTPS, ed e' quello che ChamaHub usa. La configurazione SMTP resta
> documentata nella Parte 3, per chi spedisce da un server che non sia
> Microsoft.

---

## Cosa manda email, in ChamaHub

Poco, ed e' voluto: l'applicazione e' stata costruita per funzionare anche con
la posta rotta.

| Azione | Chi spedisce | Serve davvero? |
|---|---|---|
| Creare un dipendente con invito | Edge Function `admin-users` | no: l'account nasce comunque, con password temporanea |
| «Ho dimenticato la password» | Edge Function `request-password-reset` | si', ma senza posta configurata il link finisce nei log |
| «Genera link di reimpostazione» (pagina Dipendenti) | nessuno | mai: il link lo consegna l'HR |
| Tutto il resto | nessuno | mai |

**Le email non passano dalla posta di Supabase.** Le Edge Function generano il
link con `generateLink()` - un'operazione locale al database di autenticazione,
che non spedisce niente - e poi spediscono da sole. Le impostazioni in
*Authentication → Emails → SMTP Settings* non vengono usate da ChamaHub: puoi
lasciarle vuote. Il perche' e' scritto qui sotto, ed e' anche la spiegazione
dell'errore piu' comune di questa applicazione.

### Perche' non la posta di Supabase

Quando una funzione chiedeva a Supabase di spedire (`inviteUserByEmail`,
`resetPasswordForEmail`), la chiamata restava aperta finche' GoTrue non aveva
finito di parlare con il server SMTP. Se quel server non rispondeva, la chiamata
non tornava piu': il browser prendeva un 504, e nei log compariva

```
admin-users: invio email fallito: Email non inviata: il server di posta
non ha risposto entro N secondi.
```

Quel messaggio non dice «credenziali sbagliate»: dice «nessuna risposta». E'
la differenza che conta. Una password sbagliata o SMTP AUTH spento producono un
rifiuto immediato e parlante (`535`, `5.7.57`); un'attesa a vuoto significa che
la connessione non e' mai stata stabilita. Verso Microsoft 365 la causa e' quasi
sempre una di queste due:

* **la porta 465.** Microsoft 365 accetta la posta autenticata **solo sulla 587
  con STARTTLS**. Sulla 465 non ascolta nessuno, quindi la connessione resta in
  attesa fino al timeout. E' il sintomo esatto di questo errore.
* **l'host sbagliato**: `smtp.office365.com` e' l'unico buono.
  `outlook.office365.com` serve ad altro e non risponde su SMTP.

Oggi il problema non si pone piu': l'invito e il recupero password generano il
link in locale e lo spediscono via Graph. Se la posta e' rotta, l'account viene
creato lo stesso e l'HR riceve la password temporanea da consegnare.

---

## Parte 1 — Registrare l'applicazione di posta (consigliata)

Serve una registrazione Entra ID **separata da quella del login**. Non e' un
capriccio di ordine: quella del login usa autorizzazioni delegate, che i
dipendenti si vedono chiedere al primo accesso, e nessuno vuole leggere «Invia
posta elettronica a tuo nome» entrando in un gestionale HR. Questa invece usa
un'autorizzazione **di tipo applicazione**, la usa solo la Edge Function, e le
email escono dalla casella aziendale.

### 1.1 Crea la registrazione

Azure Portal → **Microsoft Entra ID** → **Registrazioni app** → **Nuova
registrazione**.

* **Nome**: `ChamaHub - posta`
* **Tipi di account supportati**: solo questa organizzazione
* **URI di reindirizzamento**: nessuno (non c'e' nessun utente da rimandare
  indietro)

Annota **ID applicazione (client)** e **ID directory (tenant)**.

### 1.2 Aggiungi l'autorizzazione

L'API e' **Microsoft Graph**. Percorso esatto:

**Autorizzazioni API** → **Aggiungi un'autorizzazione** → riquadro grande
**Microsoft Graph** (in cima, sotto «API Microsoft più utilizzate») →
**Autorizzazioni applicazione** → scrivi `Mail.Send` nella casella di ricerca →
spunta `Mail.Send` sotto il gruppo **Mail** → **Aggiungi autorizzazioni**.

Poi premi **Concedi consenso amministratore per \<organizzazione\>**. Con le
autorizzazioni applicative non e' facoltativo.

**Come riconoscere di aver preso quella giusta.** Le due `Mail.Send` si
distinguono dalla descrizione, ed e' l'unico modo affidabile:

| Tipo | Descrizione nel portale | Vale per noi |
|---|---|---|
| Delegata | «Invia messaggi come **un** utente» | **no** |
| Applicazione | «Invia messaggi come **qualsiasi** utente» | si' |

Dopo averla aggiunta, nella tabella **Autorizzazioni configurate** la colonna
**Tipo** deve dire `Application`. Se dice `Delegate`, e' quella sbagliata - e il
segno verde «Concesso per \<organizzazione\>» accanto non vuol dire niente: il
consenso c'e', ma su un'autorizzazione che con il flusso client credentials non
viene mai usata. E' il motivo per cui il token esce senza ruoli pur avendo tutto
«verde» a schermo.

**Se `Mail.Send` non compare nell'elenco**, quasi sempre e' uno di questi tre:

* **il pannello e' rimasto su «Autorizzazioni delegate».** Sono due schede
  affiancate e si apre sempre sulla prima. `Mail.Send` esiste in entrambe -
  stesso nome, significato diverso - quindi non e' che manchi: stai guardando
  l'elenco sbagliato. Serve quella sotto **Autorizzazioni applicazione**;
* **hai scelto l'API sbagliata.** Non sono queste:
  * *Office 365 Management APIs* → serve per i log di audit e lo stato del
    servizio, non spedisce niente;
  * *Office 365 Exchange Online* → ha anche lei una `Mail.Send`, ed e' la
    trappola peggiore perche' sembra giusta. E' l'API legacy (EWS): il token
    che chiediamo e' per `graph.microsoft.com`, quindi un permesso concesso li'
    non compare fra i ruoli e Graph risponde 403;
* **l'account non ha i diritti per concedere.** Serve Amministratore globale,
  Amministratore ruoli con privilegi o Amministratore applicazioni cloud. Senza,
  la voce si aggiunge ma resta senza consenso.

**Scorciatoia, se l'interfaccia continua a non collaborare.** L'autorizzazione
si aggiunge e si concede da riga di comando, per identificativo, senza cercare
niente in un elenco:

```bash
# Azure CLI. `=Role` significa "autorizzazione applicazione";
# `=Scope` sarebbe quella delegata - e' li' che si sbaglia di solito.
az ad app permission add \
  --id <ID-APPLICAZIONE> \
  --api 00000003-0000-0000-c000-000000000000 \
  --api-permissions b633e1c5-b582-4048-a93e-9f11b44c7e96=Role

az ad app permission admin-consent --id <ID-APPLICAZIONE>
```

`00000003-0000-0000-c000-000000000000` e' Microsoft Graph;
`b633e1c5-b582-4048-a93e-9f11b44c7e96` e' `Mail.Send` applicativa.

Oppure con Microsoft Graph PowerShell, che assegna e acconsente in un colpo
solo:

```powershell
Connect-MgGraph -Scopes "Application.ReadWrite.All","AppRoleAssignment.ReadWrite.All"

$graph = Get-MgServicePrincipal -Filter "appId eq '00000003-0000-0000-c000-000000000000'"
$ruolo = $graph.AppRole | Where-Object {
  $_.Value -eq "Mail.Send" -and $_.AllowedMemberTypes -contains "Application"
}
$app = Get-MgServicePrincipal -Filter "appId eq '<ID-APPLICAZIONE>'"

New-MgServicePrincipalAppRoleAssignment `
  -ServicePrincipalId $app.Id `
  -PrincipalId $app.Id `
  -ResourceId $graph.Id `
  -AppRoleId $ruolo.Id

# Verifica: deve elencare Mail.Send
Get-MgServicePrincipalAppRoleAssignment -ServicePrincipalId $app.Id |
  Select-Object AppRoleId, ResourceDisplayName
```

> **Perche' `Mail.Send` e non `SMTP.Send`.** `SMTP.Send` e' delegata: vale solo
> con un utente collegato di cui spendere l'identita'. Qui non c'e' - chi ha
> dimenticato la password non ha una sessione, e un invito parte prima ancora
> che l'account venga usato. L'equivalente applicativo per SMTP esiste
> (`SMTP.SendAsApp`), ma userebbe comunque una connessione SMTP con XOAUTH2, che
> vuole un client scritto a mano: le librerie SMTP per Deno parlano PLAIN e
> LOGIN, non XOAUTH2. Graph ottiene lo stesso risultato con una POST.

### 1.3 Crea il segreto client

**Certificati e segreti** → **Nuovo segreto client**. Copia il **Valore** subito:
non sara' piu' leggibile. Segnati la scadenza sul calendario - un segreto
scaduto ferma la posta senza preavviso.

### 1.4 Verifica che il consenso sia stato davvero concesso

Prima di andare avanti, torna su **Autorizzazioni API** e guarda la riga di
`Mail.Send`. Devono essere vere **tutte e tre** queste cose:

* nella colonna **Tipo** c'e' scritto **Applicazione**, non *Delegata*;
* nella colonna **Stato** c'e' un segno verde con «Concesso per
  \<organizzazione\>»;
* la riga sta sotto **Microsoft Graph**, non sotto altre API.

Sono la causa numero uno del `403 ErrorAccessDenied` al primo invio. In
particolare `Mail.Send` esiste sia delegata sia applicativa, hanno lo stesso
nome, e nell'elenco si sceglie quella sbagliata senza accorgersene: con il
flusso client credentials la delegata non vale niente, e Graph risponde 403
senza spiegare perche'.

Se il log della funzione riporta «Il token non contiene NESSUN ruolo
applicativo», e' esattamente questo: il consenso non c'e', oppure
l'autorizzazione e' quella delegata.

### 1.5 Restringi il permesso a una sola casella

Cosi' com'e', `Mail.Send` applicativo permette di spedire da **qualunque**
casella del tenant. E' troppo: alla funzione ne basta una.

Il modo attuale e' **App RBAC**. Serve l'**ID oggetto** dell'entita' servizio,
che si trova in Entra ID → *Applicazioni aziendali* (non *Registrazioni app*:
sono due pagine diverse con due ID diversi, ed e' un altro classico inciampo).

```powershell
Connect-ExchangeOnline

# 1. Registra l'applicazione dentro Exchange Online
New-ServicePrincipal `
  -AppId <ID-APPLICAZIONE> `
  -ObjectId <ID-OGGETTO-ENTITA-SERVIZIO> `
  -DisplayName "ChamaHub - posta"

# 2. Definisci l'ambito: la sola casella no-reply
New-ManagementScope `
  -Name "ChamaHub-noreply" `
  -RecipientRestrictionFilter "PrimarySmtpAddress -eq 'no-reply@tuodominio.it'"

# 3. Assegna il ruolo dentro quell'ambito
New-ManagementRoleAssignment `
  -App <ID-APPLICAZIONE> `
  -Role "Application Mail.Send" `
  -CustomResourceScope "ChamaHub-noreply"
```

In alternativa, se il tenant usa ancora le vecchie **Application Access
Policy** (Microsoft le ha marcate come legacy e ne annuncera' la dismissione):

```powershell
New-ApplicationAccessPolicy `
  -AppId <ID-APPLICAZIONE> `
  -PolicyScopeGroupId no-reply@tuodominio.it `
  -AccessRight RestrictAccess `
  -Description "ChamaHub: solo la casella no-reply"

# Verifica: Granted per no-reply, Denied per chiunque altro
Test-ApplicationAccessPolicy -Identity no-reply@tuodominio.it -AppId <ID-APPLICAZIONE>
Test-ApplicationAccessPolicy -Identity unapersona@tuodominio.it -AppId <ID-APPLICAZIONE>
```

> **Aspetta prima di dire che non funziona.** Le modifiche a policy e ruoli
> possono metterci **oltre un'ora** a diventare effettive sulle chiamate a
> Graph, anche quando `Test-ApplicationAccessPolicy` risponde gia'
> correttamente. Un 403 subito dopo aver eseguito questi comandi non e'
> necessariamente un errore di configurazione.

La casella `no-reply@tuodominio.it` deve esistere e avere una licenza. Conviene
dedicarne una invece di usare quella di una persona: il giorno che quella
persona lascia l'azienda, le email smettono di partire.

**Un consiglio sull'ordine.** Se stai ancora provando, salta questo passo:
concedi `Mail.Send`, verifica che l'invio funzioni, e solo dopo restringi. Cosi'
se qualcosa non va sai da quale dei due passaggi viene, invece di avere due
sospetti e nessuna prova.

### 1.6 Imposta i secret e ridistribuisci

```bash
# L'indirizzo pubblico dell'applicazione. In produzione NON e' facoltativo:
# senza, chiunque puo' far recapitare a un collega un link che punta altrove.
# Il perche' e' in supabase/functions/_shared/links.ts e nel README.
supabase secrets set APP_URL=https://chamahub.tuodominio.it

# Facoltativo: altre origini ammesse (sviluppo, collaudo).
supabase secrets set APP_URL_ALLOWLIST="http://localhost:3000"

supabase secrets set MS_TENANT_ID=<ID-DIRECTORY>
supabase secrets set MS_CLIENT_ID=<ID-APPLICAZIONE>
supabase secrets set MS_CLIENT_SECRET='<VALORE-DEL-SEGRETO>'
supabase secrets set MS_MAIL_SENDER=no-reply@tuodominio.it

supabase functions deploy admin-users
supabase functions deploy request-password-reset
```

**La ridistribuzione non e' facoltativa**: i secret vengono letti all'avvio
della funzione, quindi una funzione gia' pubblicata continua a non vederli.
Se dopo aver impostato i secret il log dice ancora «nessun servizio di posta
configurato», e' quasi sempre questo.

I quattro secret devono esserci **tutti e quattro**: se ne manca uno, Graph
viene ignorato e si passa al canale successivo.

---

## Parte 2 — In alternativa: un servizio via HTTPS

Se preferisci non toccare Microsoft, imposta `RESEND_API_KEY` e `MAIL_FROM` e
ridistribuisci: le funzioni preferiscono Graph, poi Resend, poi SMTP. Nessuna
modifica al codice.

```bash
supabase secrets set RESEND_API_KEY='re_...'
supabase secrets set MAIL_FROM="ChamaHub <no-reply@tuodominio.it>"
```

---

## Parte 3 — In alternativa: SMTP con autenticazione di base

Ha senso per un server che non sia Microsoft 365. Verso Microsoft e' la strada
in chiusura descritta in cima a questa guida.

### Preparare Microsoft 365

Serve una cassetta con licenza da usare come mittente. Conviene dedicarne una
(`no-reply@tuodominio.it`) invece di usare quella di una persona: il giorno che
quella persona cambia password, le email smettono di partire.

#### Abilita SMTP AUTH sulla cassetta

Nei tenant creati dopo gennaio 2020 e' **spento di default**. Dal centro
amministrativo Exchange: **Destinatari → Cassette postali →** scegli la casella
**→ Gestisci app di posta elettronica →** spunta **SMTP autenticato**.

Oppure da PowerShell (Exchange Online):

```powershell
Connect-ExchangeOnline

# Sulla singola cassetta
Set-CASMailbox -Identity no-reply@tuodominio.it -SmtpClientAuthenticationDisabled $false

# Verifica: deve rispondere False
Get-CASMailbox -Identity no-reply@tuodominio.it | Format-List SmtpClientAuthenticationDisabled
```

Se il blocco e' a livello di tenant, va tolto anche li':

```powershell
Get-TransportConfig | Format-List SmtpClientAuthenticationDisabled
Set-TransportConfig -SmtpClientAuthenticationDisabled $false
```

> Lascialo disattivato a livello di tenant e attivalo **solo** sulle cassette
> che devono spedire: e' la differenza fra aprire una porta e aprire il muro.

#### Togli di mezzo MFA e Security Defaults, per quella cassetta

L'autenticazione di base non sa gestire un secondo fattore. Se il tenant ha i
**Security Defaults** attivi, SMTP AUTH e' bloccato comunque, qualunque cosa
dica l'impostazione della cassetta.

Le strade, dalla piu' pulita alla piu' sbrigativa:

1. **Accesso condizionale con esclusione mirata** (serve Entra ID P1): tieni
   MFA per tutti ed escludi la sola cassetta di servizio, limitandola per
   indirizzo IP dove possibile.
2. **Disattivare i Security Defaults** e imporre MFA con l'accesso
   condizionale: e' il passaggio che Microsoft stessa consiglia quando i
   Security Defaults diventano stretti.
3. **Password per app**: funziona solo con l'MFA per singolo utente, che e'
   anch'esso in via di pensionamento. Sconsigliata per qualcosa che deve durare.

#### Il mittente deve essere quella cassetta

L'indirizzo `From` deve coincidere con la casella autenticata, oppure quella
casella deve avere il permesso **Invia come** sull'indirizzo che vuoi usare.
Altrimenti Exchange rifiuta con `5.7.60 Client does not have permissions to send
as this sender`.

#### Limiti da conoscere

* **30 messaggi al minuto**;
* **10.000 destinatari al giorno**, contati uno per uno.

Per ChamaHub sono numeri enormi (si parla di qualche email al giorno), ma vale
la pena saperlo prima di usare la stessa casella per una newsletter.

---

### SMTP in Supabase (non usato da ChamaHub)

Il riquadro *Authentication → Emails → SMTP Settings* riguarda le email che
spedisce Supabase per conto proprio: conferma dell'indirizzo alla registrazione,
cambio email. ChamaHub non usa nessuna delle due, quindi puoi lasciarlo vuoto.
Se lo compili comunque, l'host e' `smtp.office365.com` e la porta e' **587** —
mai la 465, che verso Microsoft produce l'attesa senza risposta descritta in
cima a questa guida.

### SMTP per le Edge Function

La funzione `request-password-reset` spedisce per conto suo, quindi vuole le
stesse credenziali come secret:

```bash
supabase secrets set SMTP_HOST=smtp.office365.com
supabase secrets set SMTP_PORT=587
supabase secrets set SMTP_USER=no-reply@tuodominio.it
supabase secrets set SMTP_PASS='********'
supabase secrets set MAIL_FROM="ChamaHub <no-reply@tuodominio.it>"

supabase functions deploy request-password-reset
```

I secret sono visibili in **Edge Functions → Secrets**; non finiscono mai nel
bundle del browser.

Se un giorno passi a un servizio con API HTTPS (Resend e simili), basta
impostare `RESEND_API_KEY` e `MAIL_FROM`: la funzione preferisce quella strada e
ignora l'SMTP, senza toccare il codice.

---

## Provare che funzioni

1. **Recupero password**: dalla pagina di accesso, «Ho dimenticato la
   password» con un indirizzo davvero registrato. La schermata risponde subito
   (per costruzione), quindi l'esito vero sta in **Edge Functions → Logs →
   request-password-reset**:

   | Riga nel log | Significato |
   |---|---|
   | `email inviata via microsoft graph (no-reply@...)` | tutto a posto |
   | `invio fallito (...)` seguito da `Link generato: https://...` | la posta non ha funzionato, ma il link e' valido: puoi consegnarlo a mano mentre indaghi |
   | `nessun servizio di posta configurato` | i secret non ci sono, o non hai ridistribuito la funzione dopo averli impostati |
   | `nessun profilo attivo per l'indirizzo indicato` | l'indirizzo non e' di un dipendente attivo: nessuna email, ed e' corretto cosi' |

2. **Creazione dipendente**: crea un dipendente con «invia email di
   attivazione». Il log di `admin-users` dira' `invito inviato via ...`. Se la
   posta e' rotta l'account nasce lo stesso e compare la password temporanea con
   un avviso: e' il comportamento previsto, non un errore.

## Errori frequenti

**Microsoft Graph**

| Messaggio nel log | Causa | Rimedio |
|---|---|---|
| `nessun servizio di posta configurato` | secret assenti, oppure funzione non ridistribuita dopo averli impostati | Parte 1.5 |
| `Entra ID ha risposto 401: AADSTS7000215` | segreto client sbagliato o scaduto | Parte 1.3 |
| `Entra ID ha risposto 400: AADSTS700016` | `MS_CLIENT_ID` non corrisponde a nessuna applicazione del tenant | ricontrolla ID applicazione e ID directory |
| `AADSTS65001` (consenso non concesso) | manca il consenso amministratore su `Mail.Send` | Parte 1.2 |
| `403` + `Il token non contiene NESSUN ruolo applicativo` | `Mail.Send` aggiunta come **Delegata** invece che come **Applicazione**; oppure aggiunta sotto **Office 365 Exchange Online** invece che sotto **Microsoft Graph**; oppure consenso amministratore mancante | Parte 1.2 e 1.4 |
| `403` + `il token porta i ruoli [...] ma non Mail.Send` | registrazione sbagliata nei secret, o autorizzazione sbagliata | Parte 1.2 |
| `403` + `Access to OData is disabled` | `Mail.Send` c'e', ma la policy di Exchange esclude quella casella | Parte 1.5 (e aspetta un'ora) |
| `403` con `Mail.Send` presente nei ruoli | la casella non esiste, non ha licenza, o e' fuori dall'ambito | Parte 1.5 |
| `Microsoft Graph ha risposto 404` | la casella di `MS_MAIL_SENDER` non esiste o e' scritta male | Parte 1.5 |

**SMTP**

| Messaggio | Causa | Rimedio |
|---|---|---|
| Timeout / «non ha risposto entro N secondi» | **porta 465**: Microsoft 365 ascolta solo sulla 587 con STARTTLS. Oppure host sbagliato, oppure SMTP raggiungibile solo dalla rete aziendale | usa la 587 e `smtp.office365.com`; meglio ancora, passa a Graph (Parte 1) |
| `5.7.57 Client not authenticated to send mail` | SMTP AUTH spento sulla cassetta | Parte 1.1 |
| `535 5.7.139 Basic authentication is disabled` | bloccato dal tenant o dai Security Defaults | Parte 1.1 e 1.2 |
| `5.7.60 Client does not have permissions to send as this sender` | `MAIL_FROM` diverso dalla cassetta autenticata | Parte 1.3 |
| Timeout / nessuna risposta | porta o host sbagliati, oppure la rete di Supabase non raggiunge il vostro SMTP | prova con la 587; se e' un SMTP interno all'azienda, dall'esterno non e' raggiungibile per definizione |
| Email accettata ma mai arrivata | finita nello spam del destinatario, oppure SPF/DKIM non coprono il mittente | controlla i record del dominio |
| `Email address not authorized` | stai ancora usando il servizio interno di Supabase | Parte 2 |

Un timeout ripetuto verso un SMTP raggiungibile solo dalla rete aziendale non
si risolve con la configurazione: Supabase spedisce dai suoi server, non dai
vostri. In quel caso serve un relay accessibile da internet o un servizio via
HTTPS.

---

## Riepilogo: quale strada scegliere

| | Sopravvive al 2027 | Password da gestire | Configurazione |
|---|---|---|---|
| **Microsoft Graph** (consigliata) | si' | no, un segreto client con scadenza nota | Parte 1 |
| Servizio HTTPS (Resend e simili) | si' | no, una chiave API | Parte 2 |
| SMTP verso Microsoft 365 | no | si' | sconsigliata |
| SMTP verso un altro server | dipende dal server | si' | Parte 3 |

Il punto fermo: **niente di tutto questo blocca l'applicazione**. Se la posta
si ferma, l'HR crea gli account lo stesso e consegna i link di reimpostazione
dalla pagina Dipendenti. La posta e' una comodita', non un ingranaggio.
